from django.db import models

class ProductsType(models.Model):
    product_type = models.CharField(max_length=50)
    def __str__(self):
        return self.product_type
class author(models.Model):
    author = models.ForeignKey("auth.User", on_delete=models.CASCADE)
class BrandType(models.Model):
    brand_name = models.CharField(max_length=50, null=True, default=None)
    def __str__(self):
        return self.brand_name
class ProductsInfo(models.Model):
    name = models.CharField(max_length=70)
    price = models.CharField(max_length=20)
    brand = models.ForeignKey(BrandType, on_delete=models.CASCADE, blank=True, null=True, default=None)
    img = models.ImageField(upload_to='static/images/', blank=True)
    register_date = models.DateField(default=None)
    caption = models.TextField(default=None)
    author = models.ForeignKey("auth.User", on_delete=models.CASCADE, null=True)
    count = models.IntegerField(default=0)
    stuff = models.ForeignKey(ProductsType, on_delete=models.CASCADE, null=True)
    def __str__(self):
        return self.name + str(self.brand) +  str(self.register_date)
class StoreNames(models.Model):
    store_name = models.CharField(max_length=100)
    def __str__(self):
        return self.store_name
class Stores(models.Model):
    stuff_list = models.ManyToManyField(ProductsType)
    storeName = models.ForeignKey(StoreNames, on_delete=models.CASCADE, default=None)


