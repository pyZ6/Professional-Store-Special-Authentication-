from django.urls import path
from .views import ClothesView
from .views import ShoesViews
from .views import AccessoryShows
from .views import WatchesView
urlpatterns = [
    path("clothes/", ClothesView, name = 'clothesurl'),
    path('shoes/', ShoesViews, name = 'shoesurl'),
    path('accessories/', AccessoryShows, name = 'accessoryurl'),
    path('watches/', WatchesView, name='watchesurl'),
]