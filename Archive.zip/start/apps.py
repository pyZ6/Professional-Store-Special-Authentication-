from django.apps import AppConfig


class StartConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'start'
