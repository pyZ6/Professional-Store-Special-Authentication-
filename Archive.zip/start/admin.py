from django.contrib import admin
from .models import ProductsType
from .models import BrandType
from .models import ProductsInfo
from .models import StoreNames
from .models import Stores
from django.contrib.auth.models import User
class ProductInfoAdmin(admin.ModelAdmin):
    list_display = ('name', 'brand', 'register_date')
class StoreNameAdmin(admin.ModelAdmin):
    def has_add_permission(self, request, obj=None):
        if request.user == User.objects.get(username='lvzzy'):
            return True
        return False
    def has_view_permission(self, request, obj=None):
        if request.user == User.objects.get(username='lvzzy'):
            return True
        return False
    def has_change_permission(self, request, obj=None):
        if request.user == User.objects.get(username='lvzzy'):
            return True
        return False

    def has_delete_permission(self, request, obj=None):
        if request.user == User.objects.get(username='lvzzy'):
            return True
        return False
admin.site.register(ProductsType)
admin.site.register(BrandType)
admin.site.register(ProductsInfo, ProductInfoAdmin)
admin.site.register(StoreNames, StoreNameAdmin)
admin.site.register(Stores, StoreNameAdmin)
