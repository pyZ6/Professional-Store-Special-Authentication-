from django.shortcuts import render
import random
from django.views.generic import TemplateView
from django.views.generic import ListView
from .models import ProductsInfo
def ClothesView(request):
    Products = ProductsInfo.objects.all()
    it = iter(Products)
    ClothesList = list()

    while True:
        try:
            x = next(it)
            if str(x.stuff) == 'clothes':
                ClothesList.append(x)
            else:
                continue
        except StopIteration:
            break
    context = {
        'clotheslist' : ClothesList
    }
    return render(request, 'clothes.html', context)




def ShoesViews(request):
    Products = ProductsInfo.objects.all()
    it = iter(Products)
    ShoesSet = set()

    while True:
        try:
            x = next(it)
            if str(x.stuff) == 'shoes':
                ShoesSet.add(x)
            else:
                continue
        except StopIteration:
            break
    context = {
        'shoes':ShoesSet
    }
    return render(request, 'shoes.html', context)
def AccessoryShows(request):
    products = ProductsInfo.objects.all()
    it = iter(products)
    AccessorySet = set()
    while True:
        try:
            x = next(it)
            if str(x.stuff) == 'Accessory':
                AccessorySet.add(x)
            else:
                continue
        except StopIteration:
            break
    context = {
        'accessoryset':AccessorySet
    }
    return render(request, 'accessory.html', context)

def WatchesView(request):
    watches = ProductsInfo.objects.all()
    watches_set = set(watches)
    for watch in watches:
        watches_set.add(watch)
    context = {
        'watches':watches_set
    }
    return render(request, 'watches.html', context)
    





























